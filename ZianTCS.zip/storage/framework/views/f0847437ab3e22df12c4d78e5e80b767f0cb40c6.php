


<?php $__env->startSection('isi'); ?>

<a href="/tambahactivities" class="btn btn-success my-2">Add Activities</a>

<table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Title</th>
      <th scope="col">Explanation</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $gso25a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gsa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e($gsa->Title); ?></td>
      <td><?php echo e($gsa->Explanation); ?></td>
      
      <td>
        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                  <form class="" action="/activitiesend/<?php echo e($gsa->id); ?>" method="post">
                     <?php echo method_field('delete'); ?>
                     <?php echo csrf_field(); ?>
                     <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-danger">Delete</button>
   
                   </form>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zian\ZianTCS\resources\views/backend/activitiesend.blade.php ENDPATH**/ ?>