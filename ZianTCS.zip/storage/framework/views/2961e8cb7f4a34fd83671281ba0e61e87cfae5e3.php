

<?php $__env->startSection('isi'); ?>


<a href="/tambahactivities" class="btn btn-success my-2">Tambah gallery</a>

<table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama Barang</th>
      <th scope="col">Jumlah Barang</th>
      <th scope="col">Harga</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $glr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e($glr->nama_barang); ?></td>
      <td><?php echo e($glr->jumlah_barang); ?></td>
      <td><?php echo e($glr->harga); ?></td>
      <td>
        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                  <form class="" action="/fashionend/<?php echo e($fsh->id); ?>" method="post">
                     <?php echo method_field('delete'); ?>
                     <?php echo csrf_field(); ?>
                     <button type="submit" onclick="return confirm('Yakin dek? afa iyyah?')" class="btn btn-danger">Hapus</button>
                     <a href="/editfashion/<?php echo e($fsh->id); ?>" class="btn btn-warning">Edit</a>
                   </form>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('testposter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zian\ZianTCS\resources\views/tambahactivities.blade.php ENDPATH**/ ?>