


<?php $__env->startSection('isi'); ?>

<a href="/tambahkegiatan" class="btn btn-success my-2">Add Activities</a>

<table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">judul</th>
      <th scope="col">penjelasan</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
 
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zian\ZianTCS\resources\views/backend/kegiatanend.blade.php ENDPATH**/ ?>