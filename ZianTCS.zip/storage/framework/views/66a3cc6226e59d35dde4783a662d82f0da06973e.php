

<?php $__env->startSection('isi'); ?>

<h1 class="display-4">Mars ECC</h1>
<div class="col-8 col-sm-9">
                            <h4>Come and study with us</h4>
                            <h4>Study english in ECC</h4>
                            <h4>Make our parents be proud</h4>
                            <h4>In ECC</h4>
                            <h4>Ecc is our club</h4>
                            <h4>Ecc always in my heart</h4>
                            <h4>I believe we'll be success in ecc</h4>
                            <h4>Ecc, ooohh</h4>
                            <h4>Ecc, oooooohh</h4>
                            <h4>I believe, we'll be success in ecc</h4>
                            
                        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('testposter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\ZianTCS\resources\views/mars.blade.php ENDPATH**/ ?>