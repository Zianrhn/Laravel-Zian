


<?php $__env->startSection('isi'); ?>

<h1 class="mt-3">Add Poster</h1>

    <form method="post" action='/prosestambahposter' enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-1 col-5">
            <label for="nama" class="form-label">Title</label>
            <input class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Title" placeholder="Title" name="Title" require>
          </div>
          
          <div class="mb-3 col-5">
          <div class="form-group">
              <label for="image">Choose Foto</label>
              <input type="file" class="form-control-file" id="image" name="image">
          </div>
          <button type="submit" class="btn btn-primary">Add</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zian\ZianTCS\resources\views/backend/tambahposter.blade.php ENDPATH**/ ?>