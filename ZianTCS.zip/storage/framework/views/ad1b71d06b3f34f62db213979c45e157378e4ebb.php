


<?php $__env->startSection('isi'); ?>


<table class="table">
  <thead>
    <tr>
      <th scope="col">Name</th>
      <th scope="col">Phone</th>
      <th scope="col">Email</th>
      <th scope="col">Date</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e($dft->Name); ?></td>
      <td><?php echo e($dft->Phone); ?></td>
      <td><?php echo e($dft->Email); ?></td>
      <td><?php echo e($dft->Date); ?></td>
      
      <td>
        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                  <form class="" action="/daftar/<?php echo e($dft->id); ?>" method="post">
                     <?php echo method_field('delete'); ?>
                     <?php echo csrf_field(); ?>
                     <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-danger">Delete</button>
   
                   </form>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zian\ZianTCS\resources\views/backend/daftar.blade.php ENDPATH**/ ?>