

<?php $__env->startSection('isi'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('testposter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zian\ZianTCS\resources\views/tambahposter.blade.php ENDPATH**/ ?>