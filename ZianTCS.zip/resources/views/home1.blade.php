@extends('index')

@section('content')
    <!-- Reservation Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="reservation position-relative overlay-top overlay-bottom">
                <div class="row align-items-center">
                    <div class="col-lg-6 my-5 my-lg-0">
                        <div class="p-5">
                            <div class="mb-4">
                                <h1 class="display-3 text-primary">Online Registration</h1>
                                <h1 class="text-white">What are you waiting for?
                                     sign up and study english with us!</h1>
                            </div>
                          
                        
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="text-center p-5" style="background: rgba(51, 33, 29, .8);">
                           
                            <form method="post" action='/prosestambahdaftar' enctype="multipart/form-data">
                            @csrf
                            
                                <div class="form-group">
                                    <input class="form-control @error('nama') is-invalid @enderror bg-transparent border-primary p-4" id="Name" placeholder="Name"
                                        required="required" />
                                </div>
                                <div class="form-group">
                                    <input class="form-control @error('nama') is-invalid @enderror bg-transparent border-primary p-4" id="Phone" placeholder="Phone"
                                        required="required" />
                                </div>
                                <div class="form-group">
                                    <input class="form-control @error('nama') is-invalid @enderror bg-transparent border-primary p-4" id="Email" placeholder="Email"
                                        required="required" />
                                </div>
                               
                                <div class="form-group">
                                    <div class="date" id="date" data-target-input="nearest">
                                        <input class="form-control @error('nama') is-invalid @enderror bg-transparent border-primary p-4 datetimepicker-input" id="Date"  placeholder="Date" data-target="#date" data-toggle="datetimepicker"/>
                                    </div>
                                </div>
                        
                              
                                
                                <div>
                                    <button class="btn btn-primary btn-block font-weight-bold py-3" type="submit">Send</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Reservation End -->

@endsection