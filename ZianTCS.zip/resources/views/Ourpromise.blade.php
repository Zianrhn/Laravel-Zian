@extends ('index')

@section ('content')

<div class="container-fluid py-5">
        <div class="container">
            <div class="section-title">
                <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;"></h4>
                <h1 class="display-4">ECC PROMISE</h1>
            </div>

            <div class="container">
            
                <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;"></h4>
                <h6 class="display-4">1. Be faithful and cautious to god</h6>
                <h6 class="display-4">2. Obey the rules of ECC</h6>
                <h6 class="display-4">3. Respect the seniors and appreciate each other</h6>
                <h6 class="display-4">4. Speaking english even a little</h6>
                <h6 class="display-4">5. Be loyal to ECC</h6>
            </div>

                
                </div>
            </div>
        </div>
    </div>

@endsection